# my_site
my personal website where I practice web development in my spare time
will implement new changes to the visuals and improving overall functionality
